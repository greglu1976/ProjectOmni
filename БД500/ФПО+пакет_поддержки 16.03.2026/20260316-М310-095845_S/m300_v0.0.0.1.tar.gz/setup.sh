#!/bin/sh
#Скрипт предназначен для размещения файлов на устройстве, после распаковки архива обновления
#Скрипт является рабочим примером и решает одну задачу. Он сделан универсальным для удобства, но не предполагает решение всех возможных вариантов задач обновлени
#1. 	Поиск наличия файла с кодом заказа
#1.1 	При наличии:
#1.1.1 	Очистка /home/root/m300device/Configurations_DeviceModel/
#1.1.2	При наличии файла матрицы маппирования логики - копирование в /home/root/m300device/Configurations_DeviceModel/
#1.1.3	При наличии файла логических графов - копирование в /home/root/m300device/Configurations_DeviceModel/
#1.1.4	При наличии файлов конфигурации - копирование в /home/root/m300device/Configurations_DeviceModel/
#2.		При наличии файлов из Configurations_Technological - копирование в /home/root/m300device/Configurations_Technological/
#3.		При наличии файлов из ConfigurationsReferences - копирование в /home/root/m300device/ConfigurationsReferences/
#4.		При наличии файлов из Data_Internal_Files - копирование в /home/root/m300device/Data_Internal/

#Возвращаемые значения:
#0 - успешное завершение
#1 - Ошибка удаления
#2 - Ошибка копирования файлов
#3 - Отсутствие setparameters.sh

ConfigurationsTechnologicalFiles="
	technological_event_journal_configuration_header.bin
 	technological_event_journal_configuration.bin 
 	disturbance_recorder_signals_configuration_header.bin 
 	disturbance_recorder_signals_configuration.bin 
 	arc_protection_primary_circuit_config_header.bin 
 	arc_protection_primary_circuit_config.bin 
 	electrical_arc_matrix_header.bin 
 	electrical_arc_matrix.bin"

Data_Internal_Files="
	mibus_keeped_areas_config.bin 
	mibus_keeped_areas_retain.bin"

ConfigurationsReferencesFiles="
	order_code.txt 
	analog_channels_matrix.bin 
	electrical_arc_matrix.bin 
	ied_server.cid"

ConfigurationDeviceModelPath='/home/root/m300device/Configurations_DeviceModel/'
ConfigurationTechnologicalPath='/home/root/m300device/Configurations_Technological/'
ExecutablePath='/home/root/m300device/Executable/'
ConfigurationReferencesPath='/home/root/m300device/ConfigurationsReferences/'
DataIternalPath='/home/root/m300device/Data_Internal/'

LogicGraphFileNamePostfix='*_graph.bin'
LogicMapMatrixFileNamePostfix='*_matrix.bin'

OrderCodeFileName="order_code.txt"

#Очистка директории /home/root/m300device/Configurations_DeviceModel/
CleanConfigurationsDeviceModelDirectory () 
{
	result=`rm -rfv "$ConfigurationDeviceModelPath"*`
	if [ -z "$result" ]
	then
		echo "Ошибка удаления"$result
		exit 1
	fi	
}

#Копирование функционального программного обеспечения
CopyFunctionalSoftware ()
{
	FunctionalSoftwareFiles=`find . -name $deviceresult"*" -type f`
	if [ -n "$FunctionalSoftwareFiles" ]
	then
		CleanConfigurationsDeviceModelDirectory
		CopyFileFunction $LogicGraphFileNamePostfix $ConfigurationDeviceModelPath
		CopyFileFunction $LogicMapMatrixFileNamePostfix $ConfigurationDeviceModelPath
		echo 'Копирование файлов в '$ConfigurationDeviceModelPath
		for var in $FunctionalSoftwareFiles
		do
			cp $var $ConfigurationDeviceModelPath
			cpResult=$?
			if [ 0 -ne "$cpResult" ]
			then
				exit 2
			fi
			echo $var" - скопированный файл"
		done
		echo 'Файлы скопированы в '$ConfigurationDeviceModelPath
		return
	fi
	echo "Не найдены файлы конфигурации"
}

#Запуск реконфигурации устройства
ReconfigDevice ()
{
	local result=`find $ExecutablePath -name setparameters.sh`
	if [ -z "$result" ]
	then
		echo "Отсутствие setparameters.sh"
		exit 3
	fi
	$ExecutablePath"setparameters.sh" reconfig
}

#Функция копирования файла
CopyFileFunction ()
{
	local fileName=$1
	local pathName=$2
	result=`find . -name $fileName`
	if [ -n "$result" ]
	then
		cp $result $pathName
		cpResult=$?
		if [ 0 -ne "$cpResult" ]
		then
			exit 2 #Failed Copy 
		fi
		echo $fileName" - файл скопирован в " $pathName
	fi
}

systemctl stop m300deviced

orderCodeFilePath=`find . -name $OrderCodeFileName`
if [ -n "$orderCodeFilePath" ]
then
	deviceresult=$(cat $orderCodeFilePath)
	echo $deviceresult" - код заказа"	
	CopyFunctionalSoftware
	result=$?
	if [ 0 -ne "$result" ]
	then
		echo "Не скопированы файлы устройства"
	fi
fi

for var in $ConfigurationsTechnologicalFiles
do
	CopyFileFunction $var $ConfigurationTechnologicalPath
done

for var in $ConfigurationsReferencesFiles
do
	CopyFileFunction $var $ConfigurationReferencesPath
done

for var in $Data_Internal_Files
do
	CopyFileFunction $var $DataIternalPath
done

ReconfigDevice
result=$?
if [ 0 -ne "$result" ]
then
	echo "Ошибка при реконфигурации"
	exit $result
fi

systemctl start m300deviced
#systemctl restart m300deviced
exit 0